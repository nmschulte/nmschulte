#!/bin/bash

f=3 b=4
for j in f b; do
  for i in {0..7}; do
    printf -v $j$i %b "\e[${!j}${i}m"
  done
done
bld=$'\e[1m'
rst=$'\e[0m'
inv=$'\e[7m'


cat << EOF
$f4                               ...----....
$f4                         ..-:"''         ''"-..
$f4                      .-'                      '-.
$f4                    .'              .     .       '.
$f4                  .'   .          .    .      .    .''.
$f4                .'  .    .       .   .   .     .   . ..:.
$f4              .' .   . .  .       .   .   ..  .   . ....::.
$f4             ..   .   .      .  .    .     .  ..  . ....:IA.
$f4            .:  .   .    .    .  .  .    .. .  .. .. ....:IA.
$f4           .: .   .   ..   .    .     . . .. . ... ....:.:VHA.
$f4           '..  .  .. .   .       .  . .. . .. . .....:.::IHHB.
$f4          .:. .  . .  . .   .  .  . . . ...:.:... .......:HIHMM.
$f4         .:.... .   . ."::"'.. .   .  . .:.:.:II;,. .. ..:IHIMMA
$f4       ':.:..  ..::IHHHHHI::. . .  ...:.::::.,,,. . ....VIMMHM
$f4        .:::I. .AHHHHHHHHHHAI::. .:...,:IIHHHHHHMMMHHL:. . VMMMM
$f4       .:.:V.:IVHHHHHHHMHMHHH::..:" .:HIHHHHHHHHHHHHHMHHA. .VMMM.
$f4       :..V.:IVHHHHHMMHHHHHHHB... . .:VPHHMHHHMMHHHHHHHHHAI.:VMMI
$f4       ::V..:VIHHHHHHMMMHHHHHH. .   .I":IIMHHMMHHHHHHHHHHHAPI:WMM
$f4       ::". .:.HHHHHHHHMMHHHHHI.  . .:..I:MHMMHHHHHHHHHMHV:':H:WM
$f4       :: . :.::IIHHHHHHMMHHHHV  .ABA.:.:IMHMHMMMHMHHHHV:'. .IHWW
$f4       '.  ..:..:.:IHHHHHMMHV" .AVMHMA.:.'VHMMMMHHHHHV:' .  :IHWV
$f4        :.  .:...:".:.:TPP"   .AVMMHMMA.:. "VMMHHHP.:... .. :IVAI
$f4       .:.   '... .:"'   .   ..HMMMHMMMA::. ."VHHI:::....  .:IHW'
$f4       ...  .  . ..:IIPPIH: ..HMMMI.MMMV:I:.  .:ILLH:.. ...:I:IM
$f4     : .   .'"' .:.V". .. .  :HMMM:IMMMI::I. ..:HHIIPPHI::'.P:HM.
$f4     :.  .  .  .. ..:.. .    :AMMM IMMMM..:...:IV":T::I::.".:IHIMA
$f4     'V:.. .. . .. .  .  .   'VMMV..VMMV :....:V:.:..:....::IHHHMH
$f4       "IHH:.II:.. .:. .  . . . " :HB"" . . ..PI:.::.:::..:IHHMMV"
$f4        :IP""HHII:.  .  .    . . .'V:. . . ..:IH:.:.::IHIHHMMMMM"
$f4        :V:. VIMA:I..  .     .  . .. . .  .:.I:I:..:IHHHHMMHHMMM
$f4        :"VI:.VWMA::. .:      .   .. .:. ..:.I::.:IVHHHMMMHMMMMI
$f4        :."VIIHHMMA:.  .   .   .:  .:.. . .:.II:I:AMMMMMMHMMMMMI
$f4        :..VIHIHMMMI...::.,:.,:!"I:!"I!"I!"V:AI:VAMMMMMMHMMMMMM'
$f4        ':.:HIHIMHHA:"!!"I.:AXXXVVXXXXXXXA:."HPHIMMMMHHMHMMMMMV
$f4          V:H:I:MA:W'I :AXXXIXII:IIIISSSSSSXXA.I.VMMMHMHMMMMMM
$f4            'I::IVA ASSSSXSSSSBBSBMBSSSSSSBBMMMBS.VVMMHIMM'"'
$f4             I:: VPAIMSSSSSSSSSBSSSMMBSSSBBMMMMXXI:MMHIMMI
$f4            .I::. "H:XIIXBBMMMMMMMMMMMMMMMMMBXIXXMMPHIIMM'
$f4            :::I.  ':XSSXXIIIIXSSBMBSSXXXIIIXXSMMAMI:.IMM
$f4            :::I:.  .VSSSSSISISISSSBII:ISSSSBMMB:MI:..:MM
$f4            ::.I:.  ':"SSSSSSSISISSXIIXSSSSBMMB:AHI:..MMM.
$f4            ::.I:. . ..:"BBSSSSSSSSSSSSBBBMMMB:AHHI::.HMMI
$f4            :..::.  . ..::":BBBBBSSBBBMMMB:MMMMHHII::IHHMI
$f4            ':.I:... ....:IHHHHHMMMMMMMMMMMMMMMHHIIIIHMMV"
$f4              "V:. ..:...:.IHHHMMMMMMMMMMMMMMMMHHHMHHMHP'
$f4               ':. .:::.:.::III::IHHHHMMMMMHMHMMHHHHM"
$f4                 "::....::.:::..:..::IIIIIHHHHMMMHHMV"
$f4                   "::.::.. .. .  ...:::IIHHMMMMHMV"
$f4                     "V::... . .I::IHHMMV"'
$f4                       '"VHVHHHAHHHHMMV:"'

$rst  

EOF


