#!/bin/bash

for f in {0..6}; do
echo -en "\033[$((f+41))m\033[$((f+30))m██▓▒░"
done
echo -en "\033[37m██"

echo -e "\n"

for f in {0..6}; do
echo -en "\033[$((f+41))m\033[1;$((f+30))m██▓▒░"
done
echo -en "\033[1;37m██"

echo -e "\033[0m"


